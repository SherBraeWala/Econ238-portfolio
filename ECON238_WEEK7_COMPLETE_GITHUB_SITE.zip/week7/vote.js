// Required setup: replace this string with the URL of YOUR deployed Google Apps Script web app.
const APPS_SCRIPT_WEB_APP_URL = 'PASTE_GOOGLE_SCRIPT_WEB_APP_URL_HERE';
const form = document.getElementById('ballotForm');
const status = document.getElementById('voteStatus');
const button = document.getElementById('submitButton');
const conditionWrap = document.getElementById('conditionWrap');
const condition = document.getElementById('condition');
const idField = document.getElementById('ballot_id');
const radios = [...document.querySelectorAll('input[name="vote"]')];
let waiting = false;
const idKey = 'eco238_barred_owl_ballot_id';
const votedKey = 'eco238_barred_owl_vote_submitted';
const makeId = () => (globalThis.crypto?.randomUUID?.() || `vote-${Date.now()}-${Math.random().toString(36).slice(2)}`);
try { idField.value = localStorage.getItem(idKey) || makeId(); localStorage.setItem(idKey, idField.value); } catch { idField.value = makeId(); }
function syncConditional() {
  const selected = radios.find(r => r.checked)?.value;
  conditionWrap.hidden = selected !== 'YES_IF';
  condition.required = selected === 'YES_IF';
  if (selected !== 'YES_IF') condition.value = '';
}
radios.forEach(r => r.addEventListener('change', syncConditional));
try {
  if (localStorage.getItem(votedKey) === 'yes') {
    form.querySelector('fieldset').hidden = true;
    button.hidden = true;
    status.textContent = 'This browser already submitted a vote. Thank you.';
    status.className = 'status good';
  }
} catch {}
window.addEventListener('message', event => {
  // Google Apps Script HTML Service can nest an additional sandboxed iframe,
  // so verify the unique ballot token rather than assuming the source window.
  if (!event.data || event.data.type !== 'ECO238_OWL_BALLOT' || event.data.ballot_id !== idField.value) return;
  waiting = false;
  if (event.data.ok) {
    try { localStorage.setItem(votedKey, 'yes'); } catch {}
    form.querySelector('fieldset').hidden = true;
    button.hidden = true;
    status.textContent = 'Your vote has been recorded. Thank you for considering the tradeoff.';
    status.className = 'status good';
  } else {
    button.disabled = false;
    button.textContent = 'Try submitting again →';
    status.textContent = event.data.message || 'The vote could not be saved. Please try again.';
    status.className = 'status bad';
  }
});
form.addEventListener('submit', event => {
  if (waiting) { event.preventDefault(); return; }
  if (!APPS_SCRIPT_WEB_APP_URL.startsWith('https://script.google.com/macros/s/')) {
    event.preventDefault();
    status.textContent = 'Voting is not yet configured. The poll owner must connect the voting service before votes can be saved.';
    status.className = 'status bad';
    return;
  }
  if (document.getElementById('website').value) { event.preventDefault(); return; }
  form.action = APPS_SCRIPT_WEB_APP_URL;
  waiting = true;
  button.disabled = true;
  button.textContent = 'Submitting…';
  status.textContent = 'Saving your vote securely…';
  status.className = 'status';
  // A timeout never claims a failed or successful save: the submission may have reached Google Sheets.
  setTimeout(() => {
    if (!waiting) return;
    waiting = false;
    button.disabled = true;
    status.className = 'status bad';
    status.textContent = 'Could not confirm the vote. Please ask the poll owner to check the response sheet before submitting again.';
  }, 15000);
});
