/**
 * Eco 238 owl ballot — Google Sheets-bound Apps Script backend.
 * Spreadsheet: Extensions > Apps Script; paste this code; Deploy > Web app;
 * Execute as: Me; Who has access: Anyone.
 * Data: timestamp / vote / condition / browser-generated ballot ID.
 * No name, email, or IP address is requested by this code.
 */
function doPost(e) {
  try {
    var p = (e && e.parameter) || {};
    var choice = String(p.vote || '');
    var condition = String(p.condition || '').trim().slice(0, 400);
    var ballotId = String(p.ballot_id || '').trim().slice(0, 100);
    var honeypot = String(p.website || '');
    if (honeypot) return respond_(true, 'Recorded', ballotId); // Silent bot trap; do not store.
    if (['YES', 'NO', 'YES_IF'].indexOf(choice) < 0) throw new Error('Select a ballot option.');
    if (choice === 'YES_IF' && !condition) throw new Error('Please include a condition for YES, IF.');
    if (!ballotId) throw new Error('Invalid ballot submission.');
    // Protect spreadsheet against formula injection.
    if (/^[=+\-@]/.test(condition)) condition = "'" + condition;
    var lock = LockService.getScriptLock();
    if (!lock.tryLock(20000)) throw new Error('Poll is busy. Please try later.');
    try {
      var book = SpreadsheetApp.getActiveSpreadsheet();
      var sheet = book.getSheetByName('Votes') || book.insertSheet('Votes');
      if (sheet.getLastRow() === 0) sheet.appendRow(['Timestamp', 'Vote', 'Condition', 'Ballot ID']);
      // Deduplicate exact repeat form submissions (not identity verification).
      var last = sheet.getLastRow();
      if (last > 1) {
        var ids = sheet.getRange(2, 4, last - 1, 1).getValues();
        for (var i = 0; i < ids.length; i++) {
          if (String(ids[i][0]) === ballotId) return respond_(true, 'Already recorded', ballotId);
        }
      }
      sheet.appendRow([new Date(), choice, choice === 'YES_IF' ? condition : '', ballotId]);
      return respond_(true, 'Recorded', ballotId);
    } finally { lock.releaseLock(); }
  } catch (error) {
    return respond_(false, String(error.message || error), ballotId || '');
  }
}
function respond_(ok, message, ballotId) {
  var data = JSON.stringify({type:'ECO238_OWL_BALLOT', ok: ok, message: message, ballot_id: ballotId});
  var html = '<!doctype html><html><body><script>window.top.postMessage(' + data + ',"*");<\/script></body></html>';
  return HtmlService.createHtmlOutput(html)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
