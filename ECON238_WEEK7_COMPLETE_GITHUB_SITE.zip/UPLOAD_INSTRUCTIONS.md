# ECON 238 · Week Seven · GitHub Upload Package

## What to upload

**Upload the entire `week7` folder to the ROOT of your existing GitHub repository:**

`https://github.com/sherbraewala/Econ238-portfolio`

After GitHub Pages publishes the change, your proposed public page will be:

**https://sherbraewala.github.io/Econ238-portfolio/week7/**

(That is the expected URL, **not a verified live link until after you upload**.)

The `week7` folder is the complete **public-facing** project:
- `index.html` — full public ballot initiative, including proposition title, precise ballot question, What's the Deal, strongest YES and NO cases, buried weaknesses, economics of nonadoption, and source links. All assignment word limits checked.
- `vote.html` — simplified independent YES/NO/YES, IF ballot; the condition box becomes required only for YES, IF.
- `vote.js` — form behavior and connection point to the online vote storage service.
- `styles.css` — responsive visual design.
- `assets/owls.svg` — the local conservation illustration, displayed without outside image generation.
- `poster.html` — print-ready US-letter poster; on a published HTTPS page it generates a QR to the public proposal.

## Fastest upload into the existing repository

**GitHub Desktop method:**
1. Unzip this package to your computer. The result includes a folder named `week7`.
2. Open GitHub Desktop, clone or open the existing `sherbraewala/Econ238-portfolio` repository.
3. Copy the **whole `week7` folder** into the repository's top-level directory (beside its existing `index.html`). Do not overwrite the existing homepage.
4. In GitHub Desktop, write a commit message such as `Add Week 7 owl conservation ballot`; click **Commit** then **Push origin**.
5. Confirm that Pages is enabled at **Settings → Pages** (usually deploy from `main`, root); wait for the deploy.
6. Visit the link above. Check that the full proposal loads and that clicking Cast your vote opens the separate ballot page.

**If uploading through the GitHub website:** open the repository, select **Add file → Upload files**, and drag in the `week7` folder if your browser supports directory upload, ensuring the folder paths are preserved. If it only accepts individual files, use GitHub Desktop or create a `week7` folder first. Do **not** upload the ZIP itself expecting Pages to extract it.

## Required to ACTUALLY COLLECT votes (GitHub Pages cannot store them)

The website content is finished, but the voting service **cannot receive votes until you connect it**. All the necessary Apps Script code is provided here; the Google deployment URL comes from your account and cannot be pre-created for you.

1. Create a blank Google Sheet in an account you control; name it `ECON238 Week 7 Ballot`.
2. Open **Extensions → Apps Script**. Replace the starter code with all of `VOTING_BACKEND/Code.gs` from this package; save.
3. **Deploy → New deployment → Web app.** Use **Execute as: Me**, **Who has access: Anyone**, and grant the requested permissions. If your school account prevents public anonymous access, use another Google account you control.
4. Copy the deployed public **web app URL ending `/exec`**.
5. Edit `week7/vote.js`. Change the first line:

   `const APPS_SCRIPT_WEB_APP_URL = 'PASTE_GOOGLE_SCRIPT_WEB_APP_URL_HERE';`

   to have your actual link between the single quotes. Commit and push the updated file to GitHub.
6. Cast one test vote on the published site. Check that the `Votes` tab in Google Sheets contains the test submission. **Delete your test row**, and keep real participant votes separate.
7. The field for **YES, IF** is required when selected. Voters are not asked for names or emails. This is an informal poll, not a certified one-vote-per-person election. Browser storage and duplicate ballot IDs reduce repeat submissions but do not prove identity.

**Crucial:** Until step 5 is finished, the form visibly says that voting is not configured rather than pretending to save votes. The 14 *verbal* votes you previously collected belong in the Blackboard report, not in a fabricated online vote database.

## Poster and the assignment's two destinations

- GitHub: publish the **complete `week7` website**, including ballot and explanations. The professor expects voters to be able to read and cast a vote.
- Blackboard: submit your *separate* real-world poster photo, published Week 7 link, actual tally (5 YES / 2 NO / 7 YES, IF from your 14 verbal participants), actual paraphrased objections and conditions, and short reflection. These are not the public ballot's vote choices or data display.
- Print poster: visit the *published* `/week7/poster.html`, wait for its QR code, then print on letter-sized paper. Scan the QR with your phone first. The online QR service requires network access when printing.

## Important distinctions

- The 12% decline is from *untreated control sites* in a past U.S. Fish and Wildlife Service experimental comparison. It is not the annual decline in all owl populations and is not a predicted result of this specific Oregon pilot.
- $3 million, 2,000 birds, the 2027–2029 period, and the 20% monitoring allocation are **proposed policy terms**, not existing appropriations or price estimates.
- The existing 2024 federal barred owl strategy is real; this proposed Oregon pilot is a new, educationally formulated *funding deal*. It is a nonbinding classroom ballot, not a legally submitted Oregon referendum.

## Verification checklist

- [ ] Page `.../week7/` loads in an incognito tab.
- [ ] Proposition and six explanatory sections plus sources display completely.
- [ ] `vote.html` loads and shows YES, NO, YES, IF plus a conditional comment box.
- [ ] Apps Script URL has been added to `vote.js`.
- [ ] A test submission is confirmed in the Google Sheet; test row deleted.
- [ ] The printed poster's QR opens the correct hosted site.
- [ ] Blackboard real results/photo/reflection are submitted separately.

Sources visible to the public on the proposal page:
https://www.fws.gov/question-answer/barred-owl-management-strategy-final-eis-faqs
https://www.fws.gov/question-answer/barred-owl-management-strategy-record-decision-faqs
https://www.fws.gov/project/barred-owl-management
